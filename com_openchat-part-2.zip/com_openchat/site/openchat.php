<?php 

defined('_JEXEC') or die("Access Deny");

$controller =JControllerLegacy::getInstance("OpenChat");

$input= JFactory::getApplication()->input;

$controller->execute($input->getCmd("task"));

$controller->redirect();




 




?>