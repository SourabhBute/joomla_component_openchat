<?php 
defined('_JEXEC')or die("Acess deny");

class OpenChatController extends JControllerLegacy
{
	 function chat_history(){
	 	echo "chat history called";
	 }
	
}





?>