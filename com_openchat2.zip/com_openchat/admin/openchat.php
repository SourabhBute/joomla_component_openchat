<?php 
defined('_JEXEC') or die("Acess deny");

$controller=JControllerLegacy::getInstance("OpenChat");

$input=JFactory::getApplication()->input;

$controller->execute($input->getCmd("task"));

$controller->redirect();







?>