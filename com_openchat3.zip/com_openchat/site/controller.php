<?php 

 defined('_JEXEC') or die("Acess deny");

class OpenChatController extends JControllerLegacy
{

        function chat()
        {
        	//echo "Welcome in chat";

        	$doc=JFactory::getDocument();

        	$doc->addStyleSheet(JURI::root().'media/com_openchat/css/frontend.css');

          $doc->addScript(JURI::root().'media/com_openchat/js/jquery-3.6.0.min.js');

          $doc->addScript(JURI::root().'media/com_openchat/js/frontend.js');


        	?>
               
              <div id="openchat">
              	<div id="chat-msg-area">
              		<ul id="chat-msg">
              			<li>

              				<span class="user">Sourabh</span>
              				<span class="msg">hi</span>
                           
              			</li>

              			 <li>
              				<span class="user">Sourabh</span>
              				<span class="msg">Hello</span>
                          </li>

                          <li>
 
                            <span class="user">Sourabh</span>
              				<span class="msg">Indore</span>
                           </li>


              		</ul>

              	</div>

              	<div id="chat-toolbar">
              		<input type="text" name="msg" id="msg">
              		<input type="button" class="btn" id="chat_btn" name="chat_btn" value="send">


              	</div>


              </div>


        	<?php
        }

      function  saveChatViaAjax(){
          $app=JFactory::getApplication();
          $msg =JRequest::getString('msg','');

         $userId= JFactory::getUser()->id; 

             $res=array();


               if($msg=="")
             {  
                 $res['status']=false;
                 $res['msg']="please enter message";

                 echo json_encode($res);
                 exit();
             }
             if($userId==0)
             {

                 $res['status']=false;
                 $res['msg']="please login before chat";
                 echo json_encode($res);
                 exit();
             }

             if($chatId=$this->saveChat($msg,$userId))
            {
                //echo $chatId;
               $chatDetails=$this->getChatDetailsById($chatId);

                $res['chatDetails']=$chatDetails;
                $res['status']=true;
               
            }
            else
            {
               $res['status']=false;
               
            }


            echo  json_encode($res);

        //echo  $msg .'||'.$userId;

            

         $app->close();

      }

      // save chat 

      private function saveChat($msg,$userId){

            $userId=(INT)$userId;

            $db= JFactory::getDBO();

            $query="INSERT INTO #__openchat_msg(msg,user_id) VALUES('$msg',$userId) ";

            $db->setQuery($query);

             if($db->query())
             {

              return true ;
             }
              else
              {

                return false;
              }



      }


      //chat details 


   function getChatDetailsById($id){
          $chatId =(INT)$id;

           $db=JFactory::getDBO();

        $query= "select c.id,c.msg,u.name from qy6be_openchat_msg as c left join qy6be_users as u on c.user_id=u.id where c.id=$chatId LIMIT 1";

         $db->setQuery($query);

         return $db->loadObject();
    }







}






?>