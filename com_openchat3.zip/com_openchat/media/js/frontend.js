var JQ=jQuery.noConflict();

JQ(document).ready(function(){

    //alert("Hello Jquery");

    JQ(document).on('click','#chat_btn',function(){

       //alert("you have click on button");


       var msg=JQ('#msg').val().trim();

      // alert(msg);


         if(msg=="")
         {
           alert("Please Enter Message");
           return false;
         }

      var param ={};

      param.option="com_openchat";

      param.task="saveChatViaAjax";

      param.msg=msg;

      JQ.post('index.php',param,function(res){

        //alert(res);

          var obj= JSON.parse(res);

            if(obj.status)
            {    
            	JQ('#msg').val('');
            }else{

            	alert(obj.msg);
            }



      });





    });
});